# Use gradient descent to minimize the mean Huber error for a given dataset.
# 1) input: dataset: A N x 1 numpy array representing a dataset of numbers read in as dataset = np.loadtxt('outlier.txt')
# 2) output: der: a 1 x 1 numpy array representing the obtained Huber mean of the dataset

import numpy as np

def gradient_descent_huber(dataset):
	# Implement gradient descent for minimizing the mean Huber error for the dataset. Tip: Separate out the functions for the datapoint-wise and dataset-wise Huber errors as indicated below.

    	return optimal_alpha


def huber_error_dataset_der(dataset, alpha):
	# Compute the derivative of the mean Huber error function; note that this is the mean of the data point-wise Huber error derivatives

    	return total_error_der


def huber_error_der(x, alpha):
	# Compute the datapoint-wise Huber error derivative for the single datapoint x at the value alpha

    	return der



